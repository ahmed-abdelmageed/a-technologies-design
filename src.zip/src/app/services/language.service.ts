import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })
  export class LanguageService {
    private language = new BehaviorSubject<'ar' | 'en'>('ar'); // Default Arabic
    language$ = this.language.asObservable();
    
    private direction = new BehaviorSubject<'rtl' | 'ltr'>('rtl'); // Default RTL
    direction$ = this.direction.asObservable();
    
    private translationsSubject = new BehaviorSubject<any>({});
    translations$ = this.translationsSubject.asObservable();
    translations: any = {};
  
    constructor(private http: HttpClient) {
      const storedLang = localStorage.getItem('language') as 'ar' | 'en';
      const lang = storedLang === 'ar' || storedLang === 'en' ? storedLang : 'ar';
      this.setLanguage(lang);
    }
  
    setLanguage(lang: 'ar' | 'en') {
      localStorage.setItem('language', lang);
      const newDirection = lang === 'ar' ? 'rtl' : 'ltr';
  
      document.documentElement.lang = lang;
      document.documentElement.dir = newDirection;
  
      this.direction.next(newDirection);
  
      // ✅ Load translations and update language
      this.http.get(`assets/locales/${lang}.json`).subscribe((data) => {
        this.translations = data;
        this.translationsSubject.next(data);
        this.language.next(lang);
      });
    }
  
    // ✅ New method to get current language synchronously
    getCurrentLanguage(): 'ar' | 'en' {
      return this.language.getValue();
    }
  }
  