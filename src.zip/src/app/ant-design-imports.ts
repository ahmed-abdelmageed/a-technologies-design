import { provideNzConfig } from 'ng-zorro-antd/core/config';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzMessageService } from 'ng-zorro-antd/message';

export const ANT_DESIGN_MODULES = [
  NzTableModule,
  NzButtonModule,
  NzInputModule,
  NzModalModule
];

export const ANT_DESIGN_PROVIDERS = [
  provideNzConfig({
    message: { nzDuration: 3000 },
    button: { nzSize: 'large' },
  }),
  NzMessageService
];
