import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LanguageService } from '../../services/language.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  @Input() createdBy: string = 'عبدالرحيم إسماعيل ناهض';
  @Input() userImage: string = 'assets/images/footer-icon.png';
  @Input() creationDate: string = '01/12/2024'; 
  @Input() creationTime: string = '4:30 pm'; 

  translations: any = {}; // ✅ Store translations
  direction$: Observable<'rtl' | 'ltr'>;

  constructor(private languageService: LanguageService) {
    this.direction$ = this.languageService.direction$;
  }

  ngOnInit() {
    // ✅ Subscribe to language changes and update translations dynamically
    this.languageService.language$.subscribe(() => {
      this.translations = this.languageService.translations;
    });

    // ✅ Ensure translations load correctly on init
    this.translations = this.languageService.translations;
  }
}
