import { Component, Input, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { FormsModule } from '@angular/forms';
import { LanguageService } from '../../services/language.service';

interface Transaction {
  client: string;
  dateOfAssignment: string;
  dateOfCancellation: string;
  responsible: string;
  localContract: number;
  internationalContract: number;
  amount: number;
}

@Component({
  selector: 'app-table',
  standalone: true,
  imports: [CommonModule, NzTableModule, NzPaginationModule, NzSelectModule, FormsModule],
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit, OnChanges {
  @Input() transactions: Transaction[] = [];

  pageSize = 10;
  currentPage = 1;
  totalTransactions = 0;
  displayedTransactions: Transaction[] = [];
  pageSizeOptions = [10, 20, 50, 100];

  direction = 'rtl';
  translations: any = {};
  pageSizeOptionsFormatted: { label: string; value: number }[] = [];

  constructor(private languageService: LanguageService) {}

  ngOnInit() {
    // ✅ Subscribe to language changes and update translations immediately
    this.languageService.language$.subscribe(() => {
      this.translations = this.languageService.translations;
      this.pageSizeOptionsFormatted = this.pageSizeOptions.map(size => ({ label: `${size}`, value: size }));
    });

    // ✅ Subscribe to direction changes
    this.languageService.direction$.subscribe((dir) => {
      this.direction = dir;
    });

    // ✅ Ensure translations load correctly on init
    this.translations = this.languageService.translations;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['transactions']?.currentValue) {
      this.updatePagination();
    }
  }

  updatePagination(): void {
    this.totalTransactions = this.transactions.length;
    this.currentPage = 1;
    this.updateDisplayedTransactions();
  }

  onPageChange(page: number): void {
    this.currentPage = page;
    this.updateDisplayedTransactions();
  }

  onPageSizeChange(size: number | string): void {
    this.pageSize = Number(size);
    this.currentPage = 1;
    this.updateDisplayedTransactions();
  }

  updateDisplayedTransactions(): void {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = Math.min(startIndex + this.pageSize, this.totalTransactions);
    this.displayedTransactions = this.transactions.slice(startIndex, endIndex);
  }
}
