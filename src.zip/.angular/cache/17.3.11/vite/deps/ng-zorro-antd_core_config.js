import {
  NZ_CONFIG,
  NzConfigService,
  WithConfig,
  getStyle,
  provideNzConfig,
  registerTheme
} from "./chunk-QFVI2YBF.js";
import "./chunk-C3GV66ZD.js";
import "./chunk-FAMMGI2N.js";
import "./chunk-CMPTF2F3.js";
import "./chunk-LH2UFJUH.js";
export {
  NZ_CONFIG,
  NzConfigService,
  WithConfig,
  getStyle,
  provideNzConfig,
  registerTheme
};
//# sourceMappingURL=ng-zorro-antd_core_config.js.map
