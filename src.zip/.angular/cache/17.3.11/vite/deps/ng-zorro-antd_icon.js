import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService
} from "./chunk-BCZ6ZXWW.js";
import "./chunk-XZ2Z36PZ.js";
import "./chunk-UEVSME47.js";
import "./chunk-3I3OMAO7.js";
import "./chunk-QFVI2YBF.js";
import "./chunk-C3GV66ZD.js";
import "./chunk-QQ26ND4N.js";
import "./chunk-FAMMGI2N.js";
import "./chunk-CMPTF2F3.js";
import "./chunk-LH2UFJUH.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService
};
//# sourceMappingURL=ng-zorro-antd_icon.js.map
