import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-3UEQSEIS.js";
import "./chunk-FAMMGI2N.js";
import "./chunk-CMPTF2F3.js";
import "./chunk-LH2UFJUH.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
//# sourceMappingURL=ng-zorro-antd_core_transition-patch.js.map
