import {
  NzPaginationComponent,
  NzPaginationDefaultComponent,
  NzPaginationItemComponent,
  NzPaginationModule,
  NzPaginationOptionsComponent,
  NzPaginationSimpleComponent
} from "./chunk-TO5VHQEP.js";
import "./chunk-7F3VUSZU.js";
import "./chunk-KWWWVDW5.js";
import "./chunk-5Z6RYB6F.js";
import "./chunk-YSM4ZSFR.js";
import "./chunk-VCEXE5QX.js";
import "./chunk-RWCHWO5C.js";
import "./chunk-CBHN3EKP.js";
import "./chunk-QG6IYT37.js";
import "./chunk-C7SHARSY.js";
import "./chunk-TOFURS6Y.js";
import "./chunk-VUHEQVSU.js";
import "./chunk-BCZ6ZXWW.js";
import "./chunk-CPBK54SC.js";
import "./chunk-F5SI5K6X.js";
import "./chunk-JNP5Z3FU.js";
import "./chunk-XZ2Z36PZ.js";
import "./chunk-UEVSME47.js";
import "./chunk-3I3OMAO7.js";
import "./chunk-QFVI2YBF.js";
import "./chunk-C3GV66ZD.js";
import "./chunk-QQ26ND4N.js";
import "./chunk-FAMMGI2N.js";
import "./chunk-CMPTF2F3.js";
import "./chunk-LH2UFJUH.js";
export {
  NzPaginationComponent,
  NzPaginationDefaultComponent,
  NzPaginationItemComponent,
  NzPaginationModule,
  NzPaginationOptionsComponent,
  NzPaginationSimpleComponent
};
//# sourceMappingURL=ng-zorro-antd_pagination.js.map
