import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-7N3AYFDW.js";
import "./chunk-CPBK54SC.js";
import "./chunk-F5SI5K6X.js";
import "./chunk-JNP5Z3FU.js";
import "./chunk-XZ2Z36PZ.js";
import "./chunk-UEVSME47.js";
import "./chunk-3I3OMAO7.js";
import "./chunk-QQ26ND4N.js";
import "./chunk-FAMMGI2N.js";
import "./chunk-CMPTF2F3.js";
import "./chunk-LH2UFJUH.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
//# sourceMappingURL=ng-zorro-antd_core_wave.js.map
